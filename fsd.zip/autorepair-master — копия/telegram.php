<?php

/* https://api.telegram.org/bot7175661817:AAFNsWjtSo5aK09tPpiqWaQWhqKnHCDlbto/getUpdates,
где, XXXXXXXXXXXXXXXXXXXXXXX - токен вашего бота, полученный ранее */

$name = $_POST['user_name'];
$number = $_POST['user_number'];
$date = $_POST['user_date'];
$time = $_POST['user_time'];
$repair = $_POST['user_repair'];
$text = $_POST['user_text'];


$token = "6496967197:AAEPS6bI_q2sJEAfBDVC_47Xvi_u2hWQ7rY";
$chat_id = "-1002080459017";
$arr = array(
  'Имя пользователя: ' => $name,
  'Номер телефона: ' => $number,
  'Время: ' => $time,
  'Дата: ' => $date,
  'Сообщение: ' => $text,
  'Ремонт: ' => $repair,
);
$txt ='';
foreach($arr as $key => $value) {
  $txt .= "<b>".$key."</b> ".$value."%0A";
};

$mysql = new mysqli('localhost','rebka08a_flacar','2xT&KgIY','rebka08a_flacar');
$mysql->query("INSERT INTO flacar (name,number,date,time,repair,message)
VALUES(N'$name',N'$number','$date','$time',N'$repair',N'$text')");
$mysql->close();

$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");

if ($sendToTelegram) {
  header('location: /');
} else {
  header('location: error');
}
exit();

 

?>