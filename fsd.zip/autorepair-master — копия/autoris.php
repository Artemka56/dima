<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.6.8/axios.min.js" integrity="sha512-PJa3oQSLWRB7wHZ7GQ/g+qyv6r4mbuhmiDb8BjSFZ8NZ2a42oTtAq5n0ucWAwcQDlikAtkub+tPVCw4np27WCg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="autoriz1.css">
</head>
<body>
    <body>
        <div class="login">
            <div class="login-screen">
                <div class="app-title">
                    <h1>Авторизация</h1>
                </div>
    
                <form action="auth.php" method="POST" class="login-form">
                    <div class="control-group">
                    <input type="text" class="login-field" value="" placeholder="имя пользователя" id="login" name="k">
                    <label class="login-field-icon fui-user" for="логин"></label>
                    </div>
    
                    <div class="control-group">
                    <input type="password" class="login-field" value="" placeholder="пароль" id="pass">
                    <label class="login-field-icon fui-lock" for="логин-пароль
                    "></label>
                    </div>
    
                    <button id="signin" class="btn btn-primary btn-large btn-block" type="submit">Войти</button>
                    <a class="login-link" href="#">Забыли пароль
                        ?</a>
                    </form>
            </div>
        </div>
    </body>
    <?php
    $login = filter_var(trim($_POST['login']));
    $pass = filter_var(trim($_POST['pass']));

    $pass = md5($pass."tretgj485@958ig");

    $mysql = new mysqli('localhost','rebka08a_flacar','2xT&KgIY','rebka08a_flacar');
    
   // $result = $mysql->query("SELECT * FROM `clients` WHERE `login` = '$login' AND `pass` = '$pass'");
    $mysql->query("INSERT INTO `clients` (login,pass) VALUES('$login','$pass')");
    //$user = $result->fetch_assoc();
    // if(count($user) == 0) {
    //     echo "ТАКОГО ЧЕЛА НЕТ";
    //     exit();
    // }

    // setcookie('user', $user['login'], time() + 3600, "/");

    $mysql->close()
?>
    <!-- <script>
        const BTN_AUTH = document.querySelector("#signin");
        BTN_AUTH.addEventListener('click', (e) => {
            e.preventDefault();
            let inputLogin = document.getElementById('login-name');
            let login = inputLogin.value;
            console.log(login)
            let inputPassword = document.getElementById('login-pass');
            let password = inputPassword.value;
            // Создайте объект данных
            let data = {
                username: login,
                password: password
            };
            console.log(data)
            // Отправьте POST-запрос
            axios.post('http://localhost:8080/auth/signin', data)
                .then(function(response) {
                    console.log(response);
                    if (response != null) {
                        document.cookie = "token=" + response + "; path=/";
                        document.cookie = "username=" + data.username + "; path=/";
                        localStorage.setItem('token', response);
                        localStorage.setItem('username', data.username);
                        document.location = "profile.html";
                    }
                    console.log(response.data);
                })
                .catch(function(error) {
                    // Обработайте ошибку
                    console.log(error);
                });
        })

    </script> -->